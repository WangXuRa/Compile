# Generated from CPPParser.g4 by ANTLR 4.13.1
from antlr4 import *
if "." in __name__:
    from .CPPParser import CPPParser
else:
    from CPPParser import CPPParser

# This class defines a complete listener for a parse tree produced by CPPParser.
class CPPParserListener(ParseTreeListener):

    # Enter a parse tree produced by CPPParser#program.
    def enterProgram(self, ctx:CPPParser.ProgramContext):
        pass

    # Exit a parse tree produced by CPPParser#program.
    def exitProgram(self, ctx:CPPParser.ProgramContext):
        pass


    # Enter a parse tree produced by CPPParser#classDefinition.
    def enterClassDefinition(self, ctx:CPPParser.ClassDefinitionContext):
        pass

    # Exit a parse tree produced by CPPParser#classDefinition.
    def exitClassDefinition(self, ctx:CPPParser.ClassDefinitionContext):
        pass


    # Enter a parse tree produced by CPPParser#classBody.
    def enterClassBody(self, ctx:CPPParser.ClassBodyContext):
        pass

    # Exit a parse tree produced by CPPParser#classBody.
    def exitClassBody(self, ctx:CPPParser.ClassBodyContext):
        pass


    # Enter a parse tree produced by CPPParser#accessSpecifier.
    def enterAccessSpecifier(self, ctx:CPPParser.AccessSpecifierContext):
        pass

    # Exit a parse tree produced by CPPParser#accessSpecifier.
    def exitAccessSpecifier(self, ctx:CPPParser.AccessSpecifierContext):
        pass


    # Enter a parse tree produced by CPPParser#constructor.
    def enterConstructor(self, ctx:CPPParser.ConstructorContext):
        pass

    # Exit a parse tree produced by CPPParser#constructor.
    def exitConstructor(self, ctx:CPPParser.ConstructorContext):
        pass


    # Enter a parse tree produced by CPPParser#memberDeclaration.
    def enterMemberDeclaration(self, ctx:CPPParser.MemberDeclarationContext):
        pass

    # Exit a parse tree produced by CPPParser#memberDeclaration.
    def exitMemberDeclaration(self, ctx:CPPParser.MemberDeclarationContext):
        pass


    # Enter a parse tree produced by CPPParser#functionDefinition.
    def enterFunctionDefinition(self, ctx:CPPParser.FunctionDefinitionContext):
        pass

    # Exit a parse tree produced by CPPParser#functionDefinition.
    def exitFunctionDefinition(self, ctx:CPPParser.FunctionDefinitionContext):
        pass


    # Enter a parse tree produced by CPPParser#declaration.
    def enterDeclaration(self, ctx:CPPParser.DeclarationContext):
        pass

    # Exit a parse tree produced by CPPParser#declaration.
    def exitDeclaration(self, ctx:CPPParser.DeclarationContext):
        pass


    # Enter a parse tree produced by CPPParser#decl_.
    def enterDecl_(self, ctx:CPPParser.Decl_Context):
        pass

    # Exit a parse tree produced by CPPParser#decl_.
    def exitDecl_(self, ctx:CPPParser.Decl_Context):
        pass


    # Enter a parse tree produced by CPPParser#decl_assign.
    def enterDecl_assign(self, ctx:CPPParser.Decl_assignContext):
        pass

    # Exit a parse tree produced by CPPParser#decl_assign.
    def exitDecl_assign(self, ctx:CPPParser.Decl_assignContext):
        pass


    # Enter a parse tree produced by CPPParser#typeSpecifier.
    def enterTypeSpecifier(self, ctx:CPPParser.TypeSpecifierContext):
        pass

    # Exit a parse tree produced by CPPParser#typeSpecifier.
    def exitTypeSpecifier(self, ctx:CPPParser.TypeSpecifierContext):
        pass


    # Enter a parse tree produced by CPPParser#parameterList.
    def enterParameterList(self, ctx:CPPParser.ParameterListContext):
        pass

    # Exit a parse tree produced by CPPParser#parameterList.
    def exitParameterList(self, ctx:CPPParser.ParameterListContext):
        pass


    # Enter a parse tree produced by CPPParser#parameter.
    def enterParameter(self, ctx:CPPParser.ParameterContext):
        pass

    # Exit a parse tree produced by CPPParser#parameter.
    def exitParameter(self, ctx:CPPParser.ParameterContext):
        pass


    # Enter a parse tree produced by CPPParser#compoundStatement.
    def enterCompoundStatement(self, ctx:CPPParser.CompoundStatementContext):
        pass

    # Exit a parse tree produced by CPPParser#compoundStatement.
    def exitCompoundStatement(self, ctx:CPPParser.CompoundStatementContext):
        pass


    # Enter a parse tree produced by CPPParser#includeStatement.
    def enterIncludeStatement(self, ctx:CPPParser.IncludeStatementContext):
        pass

    # Exit a parse tree produced by CPPParser#includeStatement.
    def exitIncludeStatement(self, ctx:CPPParser.IncludeStatementContext):
        pass


    # Enter a parse tree produced by CPPParser#statement.
    def enterStatement(self, ctx:CPPParser.StatementContext):
        pass

    # Exit a parse tree produced by CPPParser#statement.
    def exitStatement(self, ctx:CPPParser.StatementContext):
        pass


    # Enter a parse tree produced by CPPParser#expressionStatement.
    def enterExpressionStatement(self, ctx:CPPParser.ExpressionStatementContext):
        pass

    # Exit a parse tree produced by CPPParser#expressionStatement.
    def exitExpressionStatement(self, ctx:CPPParser.ExpressionStatementContext):
        pass


    # Enter a parse tree produced by CPPParser#selectionStatement.
    def enterSelectionStatement(self, ctx:CPPParser.SelectionStatementContext):
        pass

    # Exit a parse tree produced by CPPParser#selectionStatement.
    def exitSelectionStatement(self, ctx:CPPParser.SelectionStatementContext):
        pass


    # Enter a parse tree produced by CPPParser#iterationStatement.
    def enterIterationStatement(self, ctx:CPPParser.IterationStatementContext):
        pass

    # Exit a parse tree produced by CPPParser#iterationStatement.
    def exitIterationStatement(self, ctx:CPPParser.IterationStatementContext):
        pass


    # Enter a parse tree produced by CPPParser#jumpStatement.
    def enterJumpStatement(self, ctx:CPPParser.JumpStatementContext):
        pass

    # Exit a parse tree produced by CPPParser#jumpStatement.
    def exitJumpStatement(self, ctx:CPPParser.JumpStatementContext):
        pass


    # Enter a parse tree produced by CPPParser#expression.
    def enterExpression(self, ctx:CPPParser.ExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#expression.
    def exitExpression(self, ctx:CPPParser.ExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#assignmentExpression.
    def enterAssignmentExpression(self, ctx:CPPParser.AssignmentExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#assignmentExpression.
    def exitAssignmentExpression(self, ctx:CPPParser.AssignmentExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#logicalOrExpression.
    def enterLogicalOrExpression(self, ctx:CPPParser.LogicalOrExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#logicalOrExpression.
    def exitLogicalOrExpression(self, ctx:CPPParser.LogicalOrExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#logicalAndExpression.
    def enterLogicalAndExpression(self, ctx:CPPParser.LogicalAndExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#logicalAndExpression.
    def exitLogicalAndExpression(self, ctx:CPPParser.LogicalAndExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#equalityExpression.
    def enterEqualityExpression(self, ctx:CPPParser.EqualityExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#equalityExpression.
    def exitEqualityExpression(self, ctx:CPPParser.EqualityExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#relationalExpression.
    def enterRelationalExpression(self, ctx:CPPParser.RelationalExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#relationalExpression.
    def exitRelationalExpression(self, ctx:CPPParser.RelationalExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#shiftExpression.
    def enterShiftExpression(self, ctx:CPPParser.ShiftExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#shiftExpression.
    def exitShiftExpression(self, ctx:CPPParser.ShiftExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#additiveExpression.
    def enterAdditiveExpression(self, ctx:CPPParser.AdditiveExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#additiveExpression.
    def exitAdditiveExpression(self, ctx:CPPParser.AdditiveExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#multiplicativeExpression.
    def enterMultiplicativeExpression(self, ctx:CPPParser.MultiplicativeExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#multiplicativeExpression.
    def exitMultiplicativeExpression(self, ctx:CPPParser.MultiplicativeExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#unaryExpression.
    def enterUnaryExpression(self, ctx:CPPParser.UnaryExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#unaryExpression.
    def exitUnaryExpression(self, ctx:CPPParser.UnaryExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#postfixExpression.
    def enterPostfixExpression(self, ctx:CPPParser.PostfixExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#postfixExpression.
    def exitPostfixExpression(self, ctx:CPPParser.PostfixExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#primaryExpression.
    def enterPrimaryExpression(self, ctx:CPPParser.PrimaryExpressionContext):
        pass

    # Exit a parse tree produced by CPPParser#primaryExpression.
    def exitPrimaryExpression(self, ctx:CPPParser.PrimaryExpressionContext):
        pass


    # Enter a parse tree produced by CPPParser#variable.
    def enterVariable(self, ctx:CPPParser.VariableContext):
        pass

    # Exit a parse tree produced by CPPParser#variable.
    def exitVariable(self, ctx:CPPParser.VariableContext):
        pass


    # Enter a parse tree produced by CPPParser#variable_.
    def enterVariable_(self, ctx:CPPParser.Variable_Context):
        pass

    # Exit a parse tree produced by CPPParser#variable_.
    def exitVariable_(self, ctx:CPPParser.Variable_Context):
        pass


    # Enter a parse tree produced by CPPParser#function.
    def enterFunction(self, ctx:CPPParser.FunctionContext):
        pass

    # Exit a parse tree produced by CPPParser#function.
    def exitFunction(self, ctx:CPPParser.FunctionContext):
        pass


    # Enter a parse tree produced by CPPParser#function_.
    def enterFunction_(self, ctx:CPPParser.Function_Context):
        pass

    # Exit a parse tree produced by CPPParser#function_.
    def exitFunction_(self, ctx:CPPParser.Function_Context):
        pass


    # Enter a parse tree produced by CPPParser#functionCall.
    def enterFunctionCall(self, ctx:CPPParser.FunctionCallContext):
        pass

    # Exit a parse tree produced by CPPParser#functionCall.
    def exitFunctionCall(self, ctx:CPPParser.FunctionCallContext):
        pass


    # Enter a parse tree produced by CPPParser#number.
    def enterNumber(self, ctx:CPPParser.NumberContext):
        pass

    # Exit a parse tree produced by CPPParser#number.
    def exitNumber(self, ctx:CPPParser.NumberContext):
        pass


    # Enter a parse tree produced by CPPParser#declarator.
    def enterDeclarator(self, ctx:CPPParser.DeclaratorContext):
        pass

    # Exit a parse tree produced by CPPParser#declarator.
    def exitDeclarator(self, ctx:CPPParser.DeclaratorContext):
        pass


    # Enter a parse tree produced by CPPParser#shiftOperator.
    def enterShiftOperator(self, ctx:CPPParser.ShiftOperatorContext):
        pass

    # Exit a parse tree produced by CPPParser#shiftOperator.
    def exitShiftOperator(self, ctx:CPPParser.ShiftOperatorContext):
        pass


    # Enter a parse tree produced by CPPParser#includeID.
    def enterIncludeID(self, ctx:CPPParser.IncludeIDContext):
        pass

    # Exit a parse tree produced by CPPParser#includeID.
    def exitIncludeID(self, ctx:CPPParser.IncludeIDContext):
        pass


    # Enter a parse tree produced by CPPParser#referenceOp.
    def enterReferenceOp(self, ctx:CPPParser.ReferenceOpContext):
        pass

    # Exit a parse tree produced by CPPParser#referenceOp.
    def exitReferenceOp(self, ctx:CPPParser.ReferenceOpContext):
        pass



del CPPParser