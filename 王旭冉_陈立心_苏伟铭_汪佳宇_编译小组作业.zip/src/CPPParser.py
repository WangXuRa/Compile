# Generated from CPPParser.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

if "." in __name__:
    from .cppParserBase import cppParserBase
else:
    from cppParserBase import cppParserBase

def serializedATN():
    return [
        4,1,55,466,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,1,0,5,0,86,8,0,10,0,12,0,89,9,0,1,0,1,0,1,0,
        1,0,5,0,95,8,0,10,0,12,0,98,9,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,
        3,2,108,8,2,1,2,1,2,1,2,1,2,3,2,114,8,2,5,2,116,8,2,10,2,12,2,119,
        9,2,1,3,1,3,1,3,1,3,1,3,1,3,3,3,127,8,3,1,4,1,4,1,4,3,4,132,8,4,
        1,4,1,4,1,4,4,4,137,8,4,11,4,12,4,138,3,4,141,8,4,1,4,1,4,1,5,1,
        5,1,5,1,5,1,6,1,6,1,6,1,6,3,6,153,8,6,1,6,1,6,1,6,1,7,1,7,1,7,1,
        7,1,7,1,7,3,7,164,8,7,1,8,1,8,1,8,1,8,5,8,170,8,8,10,8,12,8,173,
        9,8,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,5,9,184,8,9,10,9,12,9,187,
        9,9,1,10,1,10,1,10,1,10,1,10,1,10,1,10,3,10,196,8,10,1,10,3,10,199,
        8,10,1,11,1,11,1,11,5,11,204,8,11,10,11,12,11,207,9,11,1,12,1,12,
        5,12,211,8,12,10,12,12,12,214,9,12,1,12,1,12,1,13,1,13,1,13,5,13,
        221,8,13,10,13,12,13,224,9,13,1,13,1,13,1,14,1,14,1,14,1,14,1,14,
        1,15,1,15,1,15,1,15,1,15,3,15,238,8,15,1,16,3,16,241,8,16,1,16,1,
        16,1,17,1,17,1,17,1,17,1,17,1,17,1,17,3,17,252,8,17,1,18,1,18,1,
        18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,3,18,264,8,18,1,18,1,18,1,
        18,3,18,269,8,18,1,18,1,18,1,18,3,18,274,8,18,1,19,1,19,3,19,278,
        8,19,1,19,1,19,1,19,3,19,283,8,19,1,20,1,20,1,20,1,20,1,20,1,20,
        5,20,291,8,20,10,20,12,20,294,9,20,1,21,1,21,1,21,1,21,1,21,3,21,
        301,8,21,1,22,1,22,1,22,1,22,1,22,1,22,5,22,309,8,22,10,22,12,22,
        312,9,22,1,23,1,23,1,23,1,23,1,23,1,23,5,23,320,8,23,10,23,12,23,
        323,9,23,1,24,1,24,1,24,1,24,1,24,1,24,5,24,331,8,24,10,24,12,24,
        334,9,24,1,25,1,25,1,25,1,25,1,25,3,25,341,8,25,1,26,1,26,1,26,1,
        26,5,26,347,8,26,10,26,12,26,350,9,26,1,27,1,27,1,27,1,27,1,27,1,
        27,5,27,358,8,27,10,27,12,27,361,9,27,1,28,1,28,1,28,1,28,1,28,1,
        28,5,28,369,8,28,10,28,12,28,372,9,28,1,29,1,29,1,29,1,29,1,29,1,
        29,3,29,380,8,29,1,30,1,30,1,30,1,30,1,30,5,30,387,8,30,10,30,12,
        30,390,9,30,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,3,
        31,402,8,31,1,32,1,32,3,32,406,8,32,1,32,1,32,1,33,1,33,1,33,1,33,
        1,33,3,33,415,8,33,1,33,1,33,1,33,3,33,420,8,33,1,34,1,34,3,34,424,
        8,34,1,34,1,34,1,35,1,35,1,35,1,35,3,35,432,8,35,1,36,1,36,1,36,
        3,36,437,8,36,1,36,1,36,1,37,3,37,442,8,37,1,37,1,37,1,38,1,38,1,
        38,1,38,1,38,3,38,451,8,38,1,39,1,39,1,39,1,39,3,39,457,8,39,1,40,
        1,40,1,40,3,40,462,8,40,1,41,1,41,1,41,0,7,40,44,46,48,54,56,60,
        42,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,
        44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,0,7,
        1,0,11,12,1,0,9,10,1,0,5,8,1,0,1,2,2,0,3,3,12,12,2,0,15,15,28,29,
        1,0,28,29,491,0,87,1,0,0,0,2,99,1,0,0,0,4,117,1,0,0,0,6,126,1,0,
        0,0,8,128,1,0,0,0,10,144,1,0,0,0,12,148,1,0,0,0,14,163,1,0,0,0,16,
        165,1,0,0,0,18,174,1,0,0,0,20,198,1,0,0,0,22,200,1,0,0,0,24,208,
        1,0,0,0,26,217,1,0,0,0,28,227,1,0,0,0,30,237,1,0,0,0,32,240,1,0,
        0,0,34,244,1,0,0,0,36,273,1,0,0,0,38,282,1,0,0,0,40,284,1,0,0,0,
        42,300,1,0,0,0,44,302,1,0,0,0,46,313,1,0,0,0,48,324,1,0,0,0,50,340,
        1,0,0,0,52,342,1,0,0,0,54,351,1,0,0,0,56,362,1,0,0,0,58,379,1,0,
        0,0,60,381,1,0,0,0,62,401,1,0,0,0,64,405,1,0,0,0,66,419,1,0,0,0,
        68,423,1,0,0,0,70,431,1,0,0,0,72,433,1,0,0,0,74,441,1,0,0,0,76,450,
        1,0,0,0,78,456,1,0,0,0,80,458,1,0,0,0,82,463,1,0,0,0,84,86,3,28,
        14,0,85,84,1,0,0,0,86,89,1,0,0,0,87,85,1,0,0,0,87,88,1,0,0,0,88,
        96,1,0,0,0,89,87,1,0,0,0,90,95,3,2,1,0,91,95,3,12,6,0,92,95,3,14,
        7,0,93,95,3,30,15,0,94,90,1,0,0,0,94,91,1,0,0,0,94,92,1,0,0,0,94,
        93,1,0,0,0,95,98,1,0,0,0,96,94,1,0,0,0,96,97,1,0,0,0,97,1,1,0,0,
        0,98,96,1,0,0,0,99,100,5,32,0,0,100,101,5,47,0,0,101,102,5,23,0,
        0,102,103,3,4,2,0,103,104,5,24,0,0,104,105,5,16,0,0,105,3,1,0,0,
        0,106,108,3,6,3,0,107,106,1,0,0,0,107,108,1,0,0,0,108,113,1,0,0,
        0,109,114,3,8,4,0,110,114,3,14,7,0,111,114,3,12,6,0,112,114,3,10,
        5,0,113,109,1,0,0,0,113,110,1,0,0,0,113,111,1,0,0,0,113,112,1,0,
        0,0,114,116,1,0,0,0,115,107,1,0,0,0,116,119,1,0,0,0,117,115,1,0,
        0,0,117,118,1,0,0,0,118,5,1,0,0,0,119,117,1,0,0,0,120,121,5,33,0,
        0,121,127,5,19,0,0,122,123,5,34,0,0,123,127,5,19,0,0,124,125,5,35,
        0,0,125,127,5,19,0,0,126,120,1,0,0,0,126,122,1,0,0,0,126,124,1,0,
        0,0,127,7,1,0,0,0,128,129,5,47,0,0,129,131,5,21,0,0,130,132,3,22,
        11,0,131,130,1,0,0,0,131,132,1,0,0,0,132,133,1,0,0,0,133,140,5,22,
        0,0,134,136,5,19,0,0,135,137,3,72,36,0,136,135,1,0,0,0,137,138,1,
        0,0,0,138,136,1,0,0,0,138,139,1,0,0,0,139,141,1,0,0,0,140,134,1,
        0,0,0,140,141,1,0,0,0,141,142,1,0,0,0,142,143,3,26,13,0,143,9,1,
        0,0,0,144,145,3,20,10,0,145,146,3,76,38,0,146,147,5,16,0,0,147,11,
        1,0,0,0,148,149,3,20,10,0,149,150,5,47,0,0,150,152,5,21,0,0,151,
        153,3,22,11,0,152,151,1,0,0,0,152,153,1,0,0,0,153,154,1,0,0,0,154,
        155,5,22,0,0,155,156,3,26,13,0,156,13,1,0,0,0,157,158,3,16,8,0,158,
        159,5,16,0,0,159,164,1,0,0,0,160,161,3,18,9,0,161,162,5,16,0,0,162,
        164,1,0,0,0,163,157,1,0,0,0,163,160,1,0,0,0,164,15,1,0,0,0,165,166,
        3,20,10,0,166,171,3,76,38,0,167,168,5,17,0,0,168,170,3,76,38,0,169,
        167,1,0,0,0,170,173,1,0,0,0,171,169,1,0,0,0,171,172,1,0,0,0,172,
        17,1,0,0,0,173,171,1,0,0,0,174,175,3,20,10,0,175,176,3,76,38,0,176,
        177,5,4,0,0,177,185,3,42,21,0,178,179,5,17,0,0,179,180,3,76,38,0,
        180,181,5,4,0,0,181,182,3,42,21,0,182,184,1,0,0,0,183,178,1,0,0,
        0,184,187,1,0,0,0,185,183,1,0,0,0,185,186,1,0,0,0,186,19,1,0,0,0,
        187,185,1,0,0,0,188,199,5,36,0,0,189,199,5,37,0,0,190,199,5,38,0,
        0,191,199,5,39,0,0,192,199,5,45,0,0,193,194,5,47,0,0,194,196,5,20,
        0,0,195,193,1,0,0,0,195,196,1,0,0,0,196,197,1,0,0,0,197,199,5,47,
        0,0,198,188,1,0,0,0,198,189,1,0,0,0,198,190,1,0,0,0,198,191,1,0,
        0,0,198,192,1,0,0,0,198,195,1,0,0,0,199,21,1,0,0,0,200,205,3,24,
        12,0,201,202,5,17,0,0,202,204,3,24,12,0,203,201,1,0,0,0,204,207,
        1,0,0,0,205,203,1,0,0,0,205,206,1,0,0,0,206,23,1,0,0,0,207,205,1,
        0,0,0,208,212,3,20,10,0,209,211,7,0,0,0,210,209,1,0,0,0,211,214,
        1,0,0,0,212,210,1,0,0,0,212,213,1,0,0,0,213,215,1,0,0,0,214,212,
        1,0,0,0,215,216,5,47,0,0,216,25,1,0,0,0,217,222,5,23,0,0,218,221,
        3,14,7,0,219,221,3,30,15,0,220,218,1,0,0,0,220,219,1,0,0,0,221,224,
        1,0,0,0,222,220,1,0,0,0,222,223,1,0,0,0,223,225,1,0,0,0,224,222,
        1,0,0,0,225,226,5,24,0,0,226,27,1,0,0,0,227,228,5,52,0,0,228,229,
        5,5,0,0,229,230,3,80,40,0,230,231,5,6,0,0,231,29,1,0,0,0,232,238,
        3,32,16,0,233,238,3,26,13,0,234,238,3,34,17,0,235,238,3,36,18,0,
        236,238,3,38,19,0,237,232,1,0,0,0,237,233,1,0,0,0,237,234,1,0,0,
        0,237,235,1,0,0,0,237,236,1,0,0,0,238,31,1,0,0,0,239,241,3,40,20,
        0,240,239,1,0,0,0,240,241,1,0,0,0,241,242,1,0,0,0,242,243,5,16,0,
        0,243,33,1,0,0,0,244,245,5,40,0,0,245,246,5,21,0,0,246,247,3,40,
        20,0,247,248,5,22,0,0,248,251,3,30,15,0,249,250,5,41,0,0,250,252,
        3,30,15,0,251,249,1,0,0,0,251,252,1,0,0,0,252,35,1,0,0,0,253,254,
        5,43,0,0,254,255,5,21,0,0,255,256,3,40,20,0,256,257,5,22,0,0,257,
        258,3,30,15,0,258,274,1,0,0,0,259,260,5,42,0,0,260,263,5,21,0,0,
        261,264,3,18,9,0,262,264,3,42,21,0,263,261,1,0,0,0,263,262,1,0,0,
        0,264,265,1,0,0,0,265,266,5,16,0,0,266,268,3,32,16,0,267,269,3,40,
        20,0,268,267,1,0,0,0,268,269,1,0,0,0,269,270,1,0,0,0,270,271,5,22,
        0,0,271,272,3,30,15,0,272,274,1,0,0,0,273,253,1,0,0,0,273,259,1,
        0,0,0,274,37,1,0,0,0,275,277,5,44,0,0,276,278,3,40,20,0,277,276,
        1,0,0,0,277,278,1,0,0,0,278,279,1,0,0,0,279,283,5,16,0,0,280,281,
        5,46,0,0,281,283,5,16,0,0,282,275,1,0,0,0,282,280,1,0,0,0,283,39,
        1,0,0,0,284,285,6,20,-1,0,285,286,3,42,21,0,286,292,1,0,0,0,287,
        288,10,1,0,0,288,289,5,17,0,0,289,291,3,42,21,0,290,287,1,0,0,0,
        291,294,1,0,0,0,292,290,1,0,0,0,292,293,1,0,0,0,293,41,1,0,0,0,294,
        292,1,0,0,0,295,301,3,44,22,0,296,297,3,44,22,0,297,298,5,4,0,0,
        298,299,3,42,21,0,299,301,1,0,0,0,300,295,1,0,0,0,300,296,1,0,0,
        0,301,43,1,0,0,0,302,303,6,22,-1,0,303,304,3,46,23,0,304,310,1,0,
        0,0,305,306,10,1,0,0,306,307,5,14,0,0,307,309,3,46,23,0,308,305,
        1,0,0,0,309,312,1,0,0,0,310,308,1,0,0,0,310,311,1,0,0,0,311,45,1,
        0,0,0,312,310,1,0,0,0,313,314,6,23,-1,0,314,315,3,48,24,0,315,321,
        1,0,0,0,316,317,10,1,0,0,317,318,5,13,0,0,318,320,3,48,24,0,319,
        316,1,0,0,0,320,323,1,0,0,0,321,319,1,0,0,0,321,322,1,0,0,0,322,
        47,1,0,0,0,323,321,1,0,0,0,324,325,6,24,-1,0,325,326,3,50,25,0,326,
        332,1,0,0,0,327,328,10,1,0,0,328,329,7,1,0,0,329,331,3,50,25,0,330,
        327,1,0,0,0,331,334,1,0,0,0,332,330,1,0,0,0,332,333,1,0,0,0,333,
        49,1,0,0,0,334,332,1,0,0,0,335,341,3,52,26,0,336,337,3,52,26,0,337,
        338,7,2,0,0,338,339,3,52,26,0,339,341,1,0,0,0,340,335,1,0,0,0,340,
        336,1,0,0,0,341,51,1,0,0,0,342,348,3,54,27,0,343,344,3,78,39,0,344,
        345,3,54,27,0,345,347,1,0,0,0,346,343,1,0,0,0,347,350,1,0,0,0,348,
        346,1,0,0,0,348,349,1,0,0,0,349,53,1,0,0,0,350,348,1,0,0,0,351,352,
        6,27,-1,0,352,353,3,56,28,0,353,359,1,0,0,0,354,355,10,1,0,0,355,
        356,7,3,0,0,356,358,3,56,28,0,357,354,1,0,0,0,358,361,1,0,0,0,359,
        357,1,0,0,0,359,360,1,0,0,0,360,55,1,0,0,0,361,359,1,0,0,0,362,363,
        6,28,-1,0,363,364,3,58,29,0,364,370,1,0,0,0,365,366,10,1,0,0,366,
        367,7,4,0,0,367,369,3,58,29,0,368,365,1,0,0,0,369,372,1,0,0,0,370,
        368,1,0,0,0,370,371,1,0,0,0,371,57,1,0,0,0,372,370,1,0,0,0,373,380,
        3,60,30,0,374,375,7,5,0,0,375,380,3,58,29,0,376,377,3,82,41,0,377,
        378,3,58,29,0,378,380,1,0,0,0,379,373,1,0,0,0,379,374,1,0,0,0,379,
        376,1,0,0,0,380,59,1,0,0,0,381,382,6,30,-1,0,382,383,3,62,31,0,383,
        388,1,0,0,0,384,385,10,1,0,0,385,387,7,6,0,0,386,384,1,0,0,0,387,
        390,1,0,0,0,388,386,1,0,0,0,388,389,1,0,0,0,389,61,1,0,0,0,390,388,
        1,0,0,0,391,402,3,64,32,0,392,402,3,74,37,0,393,402,3,72,36,0,394,
        402,5,49,0,0,395,402,5,50,0,0,396,402,5,51,0,0,397,398,5,21,0,0,
        398,399,3,40,20,0,399,400,5,22,0,0,400,402,1,0,0,0,401,391,1,0,0,
        0,401,392,1,0,0,0,401,393,1,0,0,0,401,394,1,0,0,0,401,395,1,0,0,
        0,401,396,1,0,0,0,401,397,1,0,0,0,402,63,1,0,0,0,403,404,5,47,0,
        0,404,406,5,20,0,0,405,403,1,0,0,0,405,406,1,0,0,0,406,407,1,0,0,
        0,407,408,3,66,33,0,408,65,1,0,0,0,409,414,5,47,0,0,410,411,5,25,
        0,0,411,412,3,40,20,0,412,413,5,26,0,0,413,415,1,0,0,0,414,410,1,
        0,0,0,414,415,1,0,0,0,415,420,1,0,0,0,416,417,5,47,0,0,417,418,5,
        18,0,0,418,420,3,66,33,0,419,409,1,0,0,0,419,416,1,0,0,0,420,67,
        1,0,0,0,421,422,5,47,0,0,422,424,5,20,0,0,423,421,1,0,0,0,423,424,
        1,0,0,0,424,425,1,0,0,0,425,426,3,70,35,0,426,69,1,0,0,0,427,432,
        5,47,0,0,428,429,5,47,0,0,429,430,5,18,0,0,430,432,3,70,35,0,431,
        427,1,0,0,0,431,428,1,0,0,0,432,71,1,0,0,0,433,434,3,68,34,0,434,
        436,5,21,0,0,435,437,3,40,20,0,436,435,1,0,0,0,436,437,1,0,0,0,437,
        438,1,0,0,0,438,439,5,22,0,0,439,73,1,0,0,0,440,442,7,3,0,0,441,
        440,1,0,0,0,441,442,1,0,0,0,442,443,1,0,0,0,443,444,5,48,0,0,444,
        75,1,0,0,0,445,451,5,47,0,0,446,447,5,47,0,0,447,448,5,25,0,0,448,
        449,5,48,0,0,449,451,5,26,0,0,450,445,1,0,0,0,450,446,1,0,0,0,451,
        77,1,0,0,0,452,453,5,6,0,0,453,457,5,6,0,0,454,455,5,5,0,0,455,457,
        5,5,0,0,456,452,1,0,0,0,456,454,1,0,0,0,457,79,1,0,0,0,458,461,5,
        47,0,0,459,460,5,18,0,0,460,462,5,47,0,0,461,459,1,0,0,0,461,462,
        1,0,0,0,462,81,1,0,0,0,463,464,7,0,0,0,464,83,1,0,0,0,50,87,94,96,
        107,113,117,126,131,138,140,152,163,171,185,195,198,205,212,220,
        222,237,240,251,263,268,273,277,282,292,300,310,321,332,340,348,
        359,370,379,388,401,405,414,419,423,431,436,441,450,456,461
    ]

class CPPParser ( cppParserBase ):

    grammarFileName = "CPPParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'+'", "'-'", "'/'", "'='", "'<'", "'>'", 
                     "'<='", "'>='", "'=='", "'!='", "'&'", "'*'", "'&&'", 
                     "'||'", "'!'", "';'", "','", "'.'", "':'", "'::'", 
                     "'('", "')'", "'{'", "'}'", "'['", "']'", "'?'", "'++'", 
                     "'--'", "'+='", "'-='", "'class'", "'public'", "'private'", 
                     "'protected'", "'int'", "'double'", "'char'", "'void'", 
                     "'if'", "'else'", "'for'", "'while'", "'return'", "'bool'", 
                     "'continue'", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'#include'" ]

    symbolicNames = [ "<INVALID>", "PLUS", "MINUS", "DIV", "ASSIGN", "LT", 
                      "GT", "LE", "GE", "EQ", "NE", "AMPERSAND", "ASTERISK", 
                      "AND", "OR", "NOT", "SEMICOLON", "COMMA", "DOT", "COLON", 
                      "SCOPE", "LPAREN", "RPAREN", "LBRACE", "RBRACE", "LBRACK", 
                      "RBRACK", "QUESTION", "INCREMENT", "DECREMENT", "PLUS_ASSIGN", 
                      "MINUS_ASSIGN", "CLASS", "PUBLIC", "PRIVATE", "PROTECTED", 
                      "INT", "DOUBLE", "CHAR", "VOID", "IF", "ELSE", "FOR", 
                      "WHILE", "RETURN", "BOOL", "CONTINUE", "ID", "NUMBER", 
                      "CHAR_LITERAL", "STRING_LITERAL", "BOOL_LITERAL", 
                      "INCLUDE", "WS", "COMMENT", "MULTILINE_COMMENT" ]

    RULE_program = 0
    RULE_classDefinition = 1
    RULE_classBody = 2
    RULE_accessSpecifier = 3
    RULE_constructor = 4
    RULE_memberDeclaration = 5
    RULE_functionDefinition = 6
    RULE_declaration = 7
    RULE_decl_ = 8
    RULE_decl_assign = 9
    RULE_typeSpecifier = 10
    RULE_parameterList = 11
    RULE_parameter = 12
    RULE_compoundStatement = 13
    RULE_includeStatement = 14
    RULE_statement = 15
    RULE_expressionStatement = 16
    RULE_selectionStatement = 17
    RULE_iterationStatement = 18
    RULE_jumpStatement = 19
    RULE_expression = 20
    RULE_assignmentExpression = 21
    RULE_logicalOrExpression = 22
    RULE_logicalAndExpression = 23
    RULE_equalityExpression = 24
    RULE_relationalExpression = 25
    RULE_shiftExpression = 26
    RULE_additiveExpression = 27
    RULE_multiplicativeExpression = 28
    RULE_unaryExpression = 29
    RULE_postfixExpression = 30
    RULE_primaryExpression = 31
    RULE_variable = 32
    RULE_variable_ = 33
    RULE_function = 34
    RULE_function_ = 35
    RULE_functionCall = 36
    RULE_number = 37
    RULE_declarator = 38
    RULE_shiftOperator = 39
    RULE_includeID = 40
    RULE_referenceOp = 41

    ruleNames =  [ "program", "classDefinition", "classBody", "accessSpecifier", 
                   "constructor", "memberDeclaration", "functionDefinition", 
                   "declaration", "decl_", "decl_assign", "typeSpecifier", 
                   "parameterList", "parameter", "compoundStatement", "includeStatement", 
                   "statement", "expressionStatement", "selectionStatement", 
                   "iterationStatement", "jumpStatement", "expression", 
                   "assignmentExpression", "logicalOrExpression", "logicalAndExpression", 
                   "equalityExpression", "relationalExpression", "shiftExpression", 
                   "additiveExpression", "multiplicativeExpression", "unaryExpression", 
                   "postfixExpression", "primaryExpression", "variable", 
                   "variable_", "function", "function_", "functionCall", 
                   "number", "declarator", "shiftOperator", "includeID", 
                   "referenceOp" ]

    EOF = Token.EOF
    PLUS=1
    MINUS=2
    DIV=3
    ASSIGN=4
    LT=5
    GT=6
    LE=7
    GE=8
    EQ=9
    NE=10
    AMPERSAND=11
    ASTERISK=12
    AND=13
    OR=14
    NOT=15
    SEMICOLON=16
    COMMA=17
    DOT=18
    COLON=19
    SCOPE=20
    LPAREN=21
    RPAREN=22
    LBRACE=23
    RBRACE=24
    LBRACK=25
    RBRACK=26
    QUESTION=27
    INCREMENT=28
    DECREMENT=29
    PLUS_ASSIGN=30
    MINUS_ASSIGN=31
    CLASS=32
    PUBLIC=33
    PRIVATE=34
    PROTECTED=35
    INT=36
    DOUBLE=37
    CHAR=38
    VOID=39
    IF=40
    ELSE=41
    FOR=42
    WHILE=43
    RETURN=44
    BOOL=45
    CONTINUE=46
    ID=47
    NUMBER=48
    CHAR_LITERAL=49
    STRING_LITERAL=50
    BOOL_LITERAL=51
    INCLUDE=52
    WS=53
    COMMENT=54
    MULTILINE_COMMENT=55

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def includeStatement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.IncludeStatementContext)
            else:
                return self.getTypedRuleContext(CPPParser.IncludeStatementContext,i)


        def classDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.ClassDefinitionContext)
            else:
                return self.getTypedRuleContext(CPPParser.ClassDefinitionContext,i)


        def functionDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.FunctionDefinitionContext)
            else:
                return self.getTypedRuleContext(CPPParser.FunctionDefinitionContext,i)


        def declaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.DeclarationContext)
            else:
                return self.getTypedRuleContext(CPPParser.DeclarationContext,i)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.StatementContext)
            else:
                return self.getTypedRuleContext(CPPParser.StatementContext,i)


        def getRuleIndex(self):
            return CPPParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = CPPParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 87
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==52:
                self.state = 84
                self.includeStatement()
                self.state = 89
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 96
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 4501336995502086) != 0):
                self.state = 94
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                if la_ == 1:
                    self.state = 90
                    self.classDefinition()
                    pass

                elif la_ == 2:
                    self.state = 91
                    self.functionDefinition()
                    pass

                elif la_ == 3:
                    self.state = 92
                    self.declaration()
                    pass

                elif la_ == 4:
                    self.state = 93
                    self.statement()
                    pass


                self.state = 98
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CLASS(self):
            return self.getToken(CPPParser.CLASS, 0)

        def ID(self):
            return self.getToken(CPPParser.ID, 0)

        def LBRACE(self):
            return self.getToken(CPPParser.LBRACE, 0)

        def classBody(self):
            return self.getTypedRuleContext(CPPParser.ClassBodyContext,0)


        def RBRACE(self):
            return self.getToken(CPPParser.RBRACE, 0)

        def SEMICOLON(self):
            return self.getToken(CPPParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_classDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClassDefinition" ):
                listener.enterClassDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClassDefinition" ):
                listener.exitClassDefinition(self)




    def classDefinition(self):

        localctx = CPPParser.ClassDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_classDefinition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            self.match(CPPParser.CLASS)
            self.state = 100
            self.match(CPPParser.ID)
            self.state = 101
            self.match(CPPParser.LBRACE)
            self.state = 102
            self.classBody()
            self.state = 103
            self.match(CPPParser.RBRACE)
            self.state = 104
            self.match(CPPParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassBodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constructor(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.ConstructorContext)
            else:
                return self.getTypedRuleContext(CPPParser.ConstructorContext,i)


        def declaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.DeclarationContext)
            else:
                return self.getTypedRuleContext(CPPParser.DeclarationContext,i)


        def functionDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.FunctionDefinitionContext)
            else:
                return self.getTypedRuleContext(CPPParser.FunctionDefinitionContext,i)


        def memberDeclaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.MemberDeclarationContext)
            else:
                return self.getTypedRuleContext(CPPParser.MemberDeclarationContext,i)


        def accessSpecifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.AccessSpecifierContext)
            else:
                return self.getTypedRuleContext(CPPParser.AccessSpecifierContext,i)


        def getRuleIndex(self):
            return CPPParser.RULE_classBody

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClassBody" ):
                listener.enterClassBody(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClassBody" ):
                listener.exitClassBody(self)




    def classBody(self):

        localctx = CPPParser.ClassBodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_classBody)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 177012782137344) != 0):
                self.state = 107
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 60129542144) != 0):
                    self.state = 106
                    self.accessSpecifier()


                self.state = 113
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
                if la_ == 1:
                    self.state = 109
                    self.constructor()
                    pass

                elif la_ == 2:
                    self.state = 110
                    self.declaration()
                    pass

                elif la_ == 3:
                    self.state = 111
                    self.functionDefinition()
                    pass

                elif la_ == 4:
                    self.state = 112
                    self.memberDeclaration()
                    pass


                self.state = 119
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AccessSpecifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PUBLIC(self):
            return self.getToken(CPPParser.PUBLIC, 0)

        def COLON(self):
            return self.getToken(CPPParser.COLON, 0)

        def PRIVATE(self):
            return self.getToken(CPPParser.PRIVATE, 0)

        def PROTECTED(self):
            return self.getToken(CPPParser.PROTECTED, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_accessSpecifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAccessSpecifier" ):
                listener.enterAccessSpecifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAccessSpecifier" ):
                listener.exitAccessSpecifier(self)




    def accessSpecifier(self):

        localctx = CPPParser.AccessSpecifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_accessSpecifier)
        try:
            self.state = 126
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [33]:
                self.enterOuterAlt(localctx, 1)
                self.state = 120
                self.match(CPPParser.PUBLIC)
                self.state = 121
                self.match(CPPParser.COLON)
                pass
            elif token in [34]:
                self.enterOuterAlt(localctx, 2)
                self.state = 122
                self.match(CPPParser.PRIVATE)
                self.state = 123
                self.match(CPPParser.COLON)
                pass
            elif token in [35]:
                self.enterOuterAlt(localctx, 3)
                self.state = 124
                self.match(CPPParser.PROTECTED)
                self.state = 125
                self.match(CPPParser.COLON)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstructorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CPPParser.ID, 0)

        def LPAREN(self):
            return self.getToken(CPPParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(CPPParser.RPAREN, 0)

        def compoundStatement(self):
            return self.getTypedRuleContext(CPPParser.CompoundStatementContext,0)


        def parameterList(self):
            return self.getTypedRuleContext(CPPParser.ParameterListContext,0)


        def COLON(self):
            return self.getToken(CPPParser.COLON, 0)

        def functionCall(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.FunctionCallContext)
            else:
                return self.getTypedRuleContext(CPPParser.FunctionCallContext,i)


        def getRuleIndex(self):
            return CPPParser.RULE_constructor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstructor" ):
                listener.enterConstructor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstructor" ):
                listener.exitConstructor(self)




    def constructor(self):

        localctx = CPPParser.ConstructorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_constructor)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 128
            self.match(CPPParser.ID)
            self.state = 129
            self.match(CPPParser.LPAREN)
            self.state = 131
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 176952652595200) != 0):
                self.state = 130
                self.parameterList()


            self.state = 133
            self.match(CPPParser.RPAREN)
            self.state = 140
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==19:
                self.state = 134
                self.match(CPPParser.COLON)
                self.state = 136 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 135
                    self.functionCall()
                    self.state = 138 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==47):
                        break



            self.state = 142
            self.compoundStatement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MemberDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeSpecifier(self):
            return self.getTypedRuleContext(CPPParser.TypeSpecifierContext,0)


        def declarator(self):
            return self.getTypedRuleContext(CPPParser.DeclaratorContext,0)


        def SEMICOLON(self):
            return self.getToken(CPPParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_memberDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMemberDeclaration" ):
                listener.enterMemberDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMemberDeclaration" ):
                listener.exitMemberDeclaration(self)




    def memberDeclaration(self):

        localctx = CPPParser.MemberDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_memberDeclaration)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 144
            self.typeSpecifier()
            self.state = 145
            self.declarator()
            self.state = 146
            self.match(CPPParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeSpecifier(self):
            return self.getTypedRuleContext(CPPParser.TypeSpecifierContext,0)


        def ID(self):
            return self.getToken(CPPParser.ID, 0)

        def LPAREN(self):
            return self.getToken(CPPParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(CPPParser.RPAREN, 0)

        def compoundStatement(self):
            return self.getTypedRuleContext(CPPParser.CompoundStatementContext,0)


        def parameterList(self):
            return self.getTypedRuleContext(CPPParser.ParameterListContext,0)


        def getRuleIndex(self):
            return CPPParser.RULE_functionDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionDefinition" ):
                listener.enterFunctionDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionDefinition" ):
                listener.exitFunctionDefinition(self)




    def functionDefinition(self):

        localctx = CPPParser.FunctionDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_functionDefinition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 148
            self.typeSpecifier()
            self.state = 149
            self.match(CPPParser.ID)
            self.state = 150
            self.match(CPPParser.LPAREN)
            self.state = 152
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 176952652595200) != 0):
                self.state = 151
                self.parameterList()


            self.state = 154
            self.match(CPPParser.RPAREN)
            self.state = 155
            self.compoundStatement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def decl_(self):
            return self.getTypedRuleContext(CPPParser.Decl_Context,0)


        def SEMICOLON(self):
            return self.getToken(CPPParser.SEMICOLON, 0)

        def decl_assign(self):
            return self.getTypedRuleContext(CPPParser.Decl_assignContext,0)


        def getRuleIndex(self):
            return CPPParser.RULE_declaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaration" ):
                listener.enterDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaration" ):
                listener.exitDeclaration(self)




    def declaration(self):

        localctx = CPPParser.DeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_declaration)
        try:
            self.state = 163
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 157
                self.decl_()
                self.state = 158
                self.match(CPPParser.SEMICOLON)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 160
                self.decl_assign()
                self.state = 161
                self.match(CPPParser.SEMICOLON)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Decl_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeSpecifier(self):
            return self.getTypedRuleContext(CPPParser.TypeSpecifierContext,0)


        def declarator(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.DeclaratorContext)
            else:
                return self.getTypedRuleContext(CPPParser.DeclaratorContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.COMMA)
            else:
                return self.getToken(CPPParser.COMMA, i)

        def getRuleIndex(self):
            return CPPParser.RULE_decl_

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDecl_" ):
                listener.enterDecl_(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDecl_" ):
                listener.exitDecl_(self)




    def decl_(self):

        localctx = CPPParser.Decl_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_decl_)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 165
            self.typeSpecifier()
            self.state = 166
            self.declarator()
            self.state = 171
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==17:
                self.state = 167
                self.match(CPPParser.COMMA)
                self.state = 168
                self.declarator()
                self.state = 173
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Decl_assignContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeSpecifier(self):
            return self.getTypedRuleContext(CPPParser.TypeSpecifierContext,0)


        def declarator(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.DeclaratorContext)
            else:
                return self.getTypedRuleContext(CPPParser.DeclaratorContext,i)


        def ASSIGN(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.ASSIGN)
            else:
                return self.getToken(CPPParser.ASSIGN, i)

        def assignmentExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.AssignmentExpressionContext)
            else:
                return self.getTypedRuleContext(CPPParser.AssignmentExpressionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.COMMA)
            else:
                return self.getToken(CPPParser.COMMA, i)

        def getRuleIndex(self):
            return CPPParser.RULE_decl_assign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDecl_assign" ):
                listener.enterDecl_assign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDecl_assign" ):
                listener.exitDecl_assign(self)




    def decl_assign(self):

        localctx = CPPParser.Decl_assignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_decl_assign)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            self.typeSpecifier()
            self.state = 175
            self.declarator()
            self.state = 176
            self.match(CPPParser.ASSIGN)
            self.state = 177
            self.assignmentExpression()
            self.state = 185
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==17:
                self.state = 178
                self.match(CPPParser.COMMA)
                self.state = 179
                self.declarator()
                self.state = 180
                self.match(CPPParser.ASSIGN)
                self.state = 181
                self.assignmentExpression()
                self.state = 187
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeSpecifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(CPPParser.INT, 0)

        def DOUBLE(self):
            return self.getToken(CPPParser.DOUBLE, 0)

        def CHAR(self):
            return self.getToken(CPPParser.CHAR, 0)

        def VOID(self):
            return self.getToken(CPPParser.VOID, 0)

        def BOOL(self):
            return self.getToken(CPPParser.BOOL, 0)

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.ID)
            else:
                return self.getToken(CPPParser.ID, i)

        def SCOPE(self):
            return self.getToken(CPPParser.SCOPE, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_typeSpecifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeSpecifier" ):
                listener.enterTypeSpecifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeSpecifier" ):
                listener.exitTypeSpecifier(self)




    def typeSpecifier(self):

        localctx = CPPParser.TypeSpecifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_typeSpecifier)
        try:
            self.state = 198
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [36]:
                self.enterOuterAlt(localctx, 1)
                self.state = 188
                self.match(CPPParser.INT)
                pass
            elif token in [37]:
                self.enterOuterAlt(localctx, 2)
                self.state = 189
                self.match(CPPParser.DOUBLE)
                pass
            elif token in [38]:
                self.enterOuterAlt(localctx, 3)
                self.state = 190
                self.match(CPPParser.CHAR)
                pass
            elif token in [39]:
                self.enterOuterAlt(localctx, 4)
                self.state = 191
                self.match(CPPParser.VOID)
                pass
            elif token in [45]:
                self.enterOuterAlt(localctx, 5)
                self.state = 192
                self.match(CPPParser.BOOL)
                pass
            elif token in [47]:
                self.enterOuterAlt(localctx, 6)
                self.state = 195
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
                if la_ == 1:
                    self.state = 193
                    self.match(CPPParser.ID)
                    self.state = 194
                    self.match(CPPParser.SCOPE)


                self.state = 197
                self.match(CPPParser.ID)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.ParameterContext)
            else:
                return self.getTypedRuleContext(CPPParser.ParameterContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.COMMA)
            else:
                return self.getToken(CPPParser.COMMA, i)

        def getRuleIndex(self):
            return CPPParser.RULE_parameterList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameterList" ):
                listener.enterParameterList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameterList" ):
                listener.exitParameterList(self)




    def parameterList(self):

        localctx = CPPParser.ParameterListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_parameterList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 200
            self.parameter()
            self.state = 205
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==17:
                self.state = 201
                self.match(CPPParser.COMMA)
                self.state = 202
                self.parameter()
                self.state = 207
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeSpecifier(self):
            return self.getTypedRuleContext(CPPParser.TypeSpecifierContext,0)


        def ID(self):
            return self.getToken(CPPParser.ID, 0)

        def AMPERSAND(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.AMPERSAND)
            else:
                return self.getToken(CPPParser.AMPERSAND, i)

        def ASTERISK(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.ASTERISK)
            else:
                return self.getToken(CPPParser.ASTERISK, i)

        def getRuleIndex(self):
            return CPPParser.RULE_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameter" ):
                listener.enterParameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameter" ):
                listener.exitParameter(self)




    def parameter(self):

        localctx = CPPParser.ParameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_parameter)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 208
            self.typeSpecifier()
            self.state = 212
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==11 or _la==12:
                self.state = 209
                _la = self._input.LA(1)
                if not(_la==11 or _la==12):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 214
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 215
            self.match(CPPParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CompoundStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACE(self):
            return self.getToken(CPPParser.LBRACE, 0)

        def RBRACE(self):
            return self.getToken(CPPParser.RBRACE, 0)

        def declaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.DeclarationContext)
            else:
                return self.getTypedRuleContext(CPPParser.DeclarationContext,i)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.StatementContext)
            else:
                return self.getTypedRuleContext(CPPParser.StatementContext,i)


        def getRuleIndex(self):
            return CPPParser.RULE_compoundStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompoundStatement" ):
                listener.enterCompoundStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompoundStatement" ):
                listener.exitCompoundStatement(self)




    def compoundStatement(self):

        localctx = CPPParser.CompoundStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_compoundStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 217
            self.match(CPPParser.LBRACE)
            self.state = 222
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 4501332700534790) != 0):
                self.state = 220
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
                if la_ == 1:
                    self.state = 218
                    self.declaration()
                    pass

                elif la_ == 2:
                    self.state = 219
                    self.statement()
                    pass


                self.state = 224
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 225
            self.match(CPPParser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncludeStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INCLUDE(self):
            return self.getToken(CPPParser.INCLUDE, 0)

        def LT(self):
            return self.getToken(CPPParser.LT, 0)

        def includeID(self):
            return self.getTypedRuleContext(CPPParser.IncludeIDContext,0)


        def GT(self):
            return self.getToken(CPPParser.GT, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_includeStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIncludeStatement" ):
                listener.enterIncludeStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIncludeStatement" ):
                listener.exitIncludeStatement(self)




    def includeStatement(self):

        localctx = CPPParser.IncludeStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_includeStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 227
            self.match(CPPParser.INCLUDE)
            self.state = 228
            self.match(CPPParser.LT)
            self.state = 229
            self.includeID()
            self.state = 230
            self.match(CPPParser.GT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expressionStatement(self):
            return self.getTypedRuleContext(CPPParser.ExpressionStatementContext,0)


        def compoundStatement(self):
            return self.getTypedRuleContext(CPPParser.CompoundStatementContext,0)


        def selectionStatement(self):
            return self.getTypedRuleContext(CPPParser.SelectionStatementContext,0)


        def iterationStatement(self):
            return self.getTypedRuleContext(CPPParser.IterationStatementContext,0)


        def jumpStatement(self):
            return self.getTypedRuleContext(CPPParser.JumpStatementContext,0)


        def getRuleIndex(self):
            return CPPParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)




    def statement(self):

        localctx = CPPParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_statement)
        try:
            self.state = 237
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2, 11, 12, 15, 16, 21, 28, 29, 47, 48, 49, 50, 51]:
                self.enterOuterAlt(localctx, 1)
                self.state = 232
                self.expressionStatement()
                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 2)
                self.state = 233
                self.compoundStatement()
                pass
            elif token in [40]:
                self.enterOuterAlt(localctx, 3)
                self.state = 234
                self.selectionStatement()
                pass
            elif token in [42, 43]:
                self.enterOuterAlt(localctx, 4)
                self.state = 235
                self.iterationStatement()
                pass
            elif token in [44, 46]:
                self.enterOuterAlt(localctx, 5)
                self.state = 236
                self.jumpStatement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SEMICOLON(self):
            return self.getToken(CPPParser.SEMICOLON, 0)

        def expression(self):
            return self.getTypedRuleContext(CPPParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CPPParser.RULE_expressionStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressionStatement" ):
                listener.enterExpressionStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressionStatement" ):
                listener.exitExpressionStatement(self)




    def expressionStatement(self):

        localctx = CPPParser.ExpressionStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_expressionStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 240
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 4362862946457606) != 0):
                self.state = 239
                self.expression(0)


            self.state = 242
            self.match(CPPParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SelectionStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(CPPParser.IF, 0)

        def LPAREN(self):
            return self.getToken(CPPParser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(CPPParser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(CPPParser.RPAREN, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.StatementContext)
            else:
                return self.getTypedRuleContext(CPPParser.StatementContext,i)


        def ELSE(self):
            return self.getToken(CPPParser.ELSE, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_selectionStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSelectionStatement" ):
                listener.enterSelectionStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSelectionStatement" ):
                listener.exitSelectionStatement(self)




    def selectionStatement(self):

        localctx = CPPParser.SelectionStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_selectionStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 244
            self.match(CPPParser.IF)
            self.state = 245
            self.match(CPPParser.LPAREN)
            self.state = 246
            self.expression(0)
            self.state = 247
            self.match(CPPParser.RPAREN)
            self.state = 248
            self.statement()
            self.state = 251
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
            if la_ == 1:
                self.state = 249
                self.match(CPPParser.ELSE)
                self.state = 250
                self.statement()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IterationStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(CPPParser.WHILE, 0)

        def LPAREN(self):
            return self.getToken(CPPParser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(CPPParser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(CPPParser.RPAREN, 0)

        def statement(self):
            return self.getTypedRuleContext(CPPParser.StatementContext,0)


        def FOR(self):
            return self.getToken(CPPParser.FOR, 0)

        def SEMICOLON(self):
            return self.getToken(CPPParser.SEMICOLON, 0)

        def expressionStatement(self):
            return self.getTypedRuleContext(CPPParser.ExpressionStatementContext,0)


        def decl_assign(self):
            return self.getTypedRuleContext(CPPParser.Decl_assignContext,0)


        def assignmentExpression(self):
            return self.getTypedRuleContext(CPPParser.AssignmentExpressionContext,0)


        def getRuleIndex(self):
            return CPPParser.RULE_iterationStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIterationStatement" ):
                listener.enterIterationStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIterationStatement" ):
                listener.exitIterationStatement(self)




    def iterationStatement(self):

        localctx = CPPParser.IterationStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_iterationStatement)
        self._la = 0 # Token type
        try:
            self.state = 273
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [43]:
                self.enterOuterAlt(localctx, 1)
                self.state = 253
                self.match(CPPParser.WHILE)
                self.state = 254
                self.match(CPPParser.LPAREN)
                self.state = 255
                self.expression(0)
                self.state = 256
                self.match(CPPParser.RPAREN)
                self.state = 257
                self.statement()
                pass
            elif token in [42]:
                self.enterOuterAlt(localctx, 2)
                self.state = 259
                self.match(CPPParser.FOR)
                self.state = 260
                self.match(CPPParser.LPAREN)
                self.state = 263
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,23,self._ctx)
                if la_ == 1:
                    self.state = 261
                    self.decl_assign()
                    pass

                elif la_ == 2:
                    self.state = 262
                    self.assignmentExpression()
                    pass


                self.state = 265
                self.match(CPPParser.SEMICOLON)
                self.state = 266
                self.expressionStatement()
                self.state = 268
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 4362862946457606) != 0):
                    self.state = 267
                    self.expression(0)


                self.state = 270
                self.match(CPPParser.RPAREN)
                self.state = 271
                self.statement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class JumpStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(CPPParser.RETURN, 0)

        def SEMICOLON(self):
            return self.getToken(CPPParser.SEMICOLON, 0)

        def expression(self):
            return self.getTypedRuleContext(CPPParser.ExpressionContext,0)


        def CONTINUE(self):
            return self.getToken(CPPParser.CONTINUE, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_jumpStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJumpStatement" ):
                listener.enterJumpStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJumpStatement" ):
                listener.exitJumpStatement(self)




    def jumpStatement(self):

        localctx = CPPParser.JumpStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_jumpStatement)
        self._la = 0 # Token type
        try:
            self.state = 282
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [44]:
                self.enterOuterAlt(localctx, 1)
                self.state = 275
                self.match(CPPParser.RETURN)
                self.state = 277
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 4362862946457606) != 0):
                    self.state = 276
                    self.expression(0)


                self.state = 279
                self.match(CPPParser.SEMICOLON)
                pass
            elif token in [46]:
                self.enterOuterAlt(localctx, 2)
                self.state = 280
                self.match(CPPParser.CONTINUE)
                self.state = 281
                self.match(CPPParser.SEMICOLON)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assignmentExpression(self):
            return self.getTypedRuleContext(CPPParser.AssignmentExpressionContext,0)


        def expression(self):
            return self.getTypedRuleContext(CPPParser.ExpressionContext,0)


        def COMMA(self):
            return self.getToken(CPPParser.COMMA, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CPPParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 40
        self.enterRecursionRule(localctx, 40, self.RULE_expression, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 285
            self.assignmentExpression()
            self._ctx.stop = self._input.LT(-1)
            self.state = 292
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,28,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CPPParser.ExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                    self.state = 287
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 288
                    self.match(CPPParser.COMMA)
                    self.state = 289
                    self.assignmentExpression() 
                self.state = 294
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,28,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class AssignmentExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def logicalOrExpression(self):
            return self.getTypedRuleContext(CPPParser.LogicalOrExpressionContext,0)


        def ASSIGN(self):
            return self.getToken(CPPParser.ASSIGN, 0)

        def assignmentExpression(self):
            return self.getTypedRuleContext(CPPParser.AssignmentExpressionContext,0)


        def getRuleIndex(self):
            return CPPParser.RULE_assignmentExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignmentExpression" ):
                listener.enterAssignmentExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignmentExpression" ):
                listener.exitAssignmentExpression(self)




    def assignmentExpression(self):

        localctx = CPPParser.AssignmentExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_assignmentExpression)
        try:
            self.state = 300
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 295
                self.logicalOrExpression(0)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 296
                self.logicalOrExpression(0)
                self.state = 297
                self.match(CPPParser.ASSIGN)
                self.state = 298
                self.assignmentExpression()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogicalOrExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def logicalAndExpression(self):
            return self.getTypedRuleContext(CPPParser.LogicalAndExpressionContext,0)


        def logicalOrExpression(self):
            return self.getTypedRuleContext(CPPParser.LogicalOrExpressionContext,0)


        def OR(self):
            return self.getToken(CPPParser.OR, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_logicalOrExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalOrExpression" ):
                listener.enterLogicalOrExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalOrExpression" ):
                listener.exitLogicalOrExpression(self)



    def logicalOrExpression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CPPParser.LogicalOrExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 44
        self.enterRecursionRule(localctx, 44, self.RULE_logicalOrExpression, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 303
            self.logicalAndExpression(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 310
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,30,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CPPParser.LogicalOrExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_logicalOrExpression)
                    self.state = 305
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 306
                    self.match(CPPParser.OR)
                    self.state = 307
                    self.logicalAndExpression(0) 
                self.state = 312
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,30,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class LogicalAndExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def equalityExpression(self):
            return self.getTypedRuleContext(CPPParser.EqualityExpressionContext,0)


        def logicalAndExpression(self):
            return self.getTypedRuleContext(CPPParser.LogicalAndExpressionContext,0)


        def AND(self):
            return self.getToken(CPPParser.AND, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_logicalAndExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalAndExpression" ):
                listener.enterLogicalAndExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalAndExpression" ):
                listener.exitLogicalAndExpression(self)



    def logicalAndExpression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CPPParser.LogicalAndExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 46
        self.enterRecursionRule(localctx, 46, self.RULE_logicalAndExpression, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 314
            self.equalityExpression(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 321
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,31,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CPPParser.LogicalAndExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_logicalAndExpression)
                    self.state = 316
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 317
                    self.match(CPPParser.AND)
                    self.state = 318
                    self.equalityExpression(0) 
                self.state = 323
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,31,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class EqualityExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def relationalExpression(self):
            return self.getTypedRuleContext(CPPParser.RelationalExpressionContext,0)


        def equalityExpression(self):
            return self.getTypedRuleContext(CPPParser.EqualityExpressionContext,0)


        def EQ(self):
            return self.getToken(CPPParser.EQ, 0)

        def NE(self):
            return self.getToken(CPPParser.NE, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_equalityExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEqualityExpression" ):
                listener.enterEqualityExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEqualityExpression" ):
                listener.exitEqualityExpression(self)



    def equalityExpression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CPPParser.EqualityExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 48
        self.enterRecursionRule(localctx, 48, self.RULE_equalityExpression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 325
            self.relationalExpression()
            self._ctx.stop = self._input.LT(-1)
            self.state = 332
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,32,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CPPParser.EqualityExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_equalityExpression)
                    self.state = 327
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 328
                    _la = self._input.LA(1)
                    if not(_la==9 or _la==10):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 329
                    self.relationalExpression() 
                self.state = 334
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,32,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class RelationalExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def shiftExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.ShiftExpressionContext)
            else:
                return self.getTypedRuleContext(CPPParser.ShiftExpressionContext,i)


        def LT(self):
            return self.getToken(CPPParser.LT, 0)

        def GT(self):
            return self.getToken(CPPParser.GT, 0)

        def LE(self):
            return self.getToken(CPPParser.LE, 0)

        def GE(self):
            return self.getToken(CPPParser.GE, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_relationalExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelationalExpression" ):
                listener.enterRelationalExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelationalExpression" ):
                listener.exitRelationalExpression(self)




    def relationalExpression(self):

        localctx = CPPParser.RelationalExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_relationalExpression)
        self._la = 0 # Token type
        try:
            self.state = 340
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 335
                self.shiftExpression()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 336
                self.shiftExpression()
                self.state = 337
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 480) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 338
                self.shiftExpression()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShiftExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def additiveExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.AdditiveExpressionContext)
            else:
                return self.getTypedRuleContext(CPPParser.AdditiveExpressionContext,i)


        def shiftOperator(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CPPParser.ShiftOperatorContext)
            else:
                return self.getTypedRuleContext(CPPParser.ShiftOperatorContext,i)


        def getRuleIndex(self):
            return CPPParser.RULE_shiftExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShiftExpression" ):
                listener.enterShiftExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShiftExpression" ):
                listener.exitShiftExpression(self)




    def shiftExpression(self):

        localctx = CPPParser.ShiftExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_shiftExpression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 342
            self.additiveExpression(0)
            self.state = 348
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,34,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 343
                    self.shiftOperator()
                    self.state = 344
                    self.additiveExpression(0) 
                self.state = 350
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,34,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdditiveExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def multiplicativeExpression(self):
            return self.getTypedRuleContext(CPPParser.MultiplicativeExpressionContext,0)


        def additiveExpression(self):
            return self.getTypedRuleContext(CPPParser.AdditiveExpressionContext,0)


        def PLUS(self):
            return self.getToken(CPPParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(CPPParser.MINUS, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_additiveExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdditiveExpression" ):
                listener.enterAdditiveExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdditiveExpression" ):
                listener.exitAdditiveExpression(self)



    def additiveExpression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CPPParser.AdditiveExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 54
        self.enterRecursionRule(localctx, 54, self.RULE_additiveExpression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 352
            self.multiplicativeExpression(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 359
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,35,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CPPParser.AdditiveExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_additiveExpression)
                    self.state = 354
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 355
                    _la = self._input.LA(1)
                    if not(_la==1 or _la==2):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 356
                    self.multiplicativeExpression(0) 
                self.state = 361
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,35,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class MultiplicativeExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unaryExpression(self):
            return self.getTypedRuleContext(CPPParser.UnaryExpressionContext,0)


        def multiplicativeExpression(self):
            return self.getTypedRuleContext(CPPParser.MultiplicativeExpressionContext,0)


        def ASTERISK(self):
            return self.getToken(CPPParser.ASTERISK, 0)

        def DIV(self):
            return self.getToken(CPPParser.DIV, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_multiplicativeExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicativeExpression" ):
                listener.enterMultiplicativeExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicativeExpression" ):
                listener.exitMultiplicativeExpression(self)



    def multiplicativeExpression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CPPParser.MultiplicativeExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 56
        self.enterRecursionRule(localctx, 56, self.RULE_multiplicativeExpression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 363
            self.unaryExpression()
            self._ctx.stop = self._input.LT(-1)
            self.state = 370
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,36,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CPPParser.MultiplicativeExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_multiplicativeExpression)
                    self.state = 365
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 366
                    _la = self._input.LA(1)
                    if not(_la==3 or _la==12):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 367
                    self.unaryExpression() 
                self.state = 372
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,36,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class UnaryExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def postfixExpression(self):
            return self.getTypedRuleContext(CPPParser.PostfixExpressionContext,0)


        def unaryExpression(self):
            return self.getTypedRuleContext(CPPParser.UnaryExpressionContext,0)


        def INCREMENT(self):
            return self.getToken(CPPParser.INCREMENT, 0)

        def DECREMENT(self):
            return self.getToken(CPPParser.DECREMENT, 0)

        def NOT(self):
            return self.getToken(CPPParser.NOT, 0)

        def referenceOp(self):
            return self.getTypedRuleContext(CPPParser.ReferenceOpContext,0)


        def getRuleIndex(self):
            return CPPParser.RULE_unaryExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryExpression" ):
                listener.enterUnaryExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryExpression" ):
                listener.exitUnaryExpression(self)




    def unaryExpression(self):

        localctx = CPPParser.UnaryExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_unaryExpression)
        self._la = 0 # Token type
        try:
            self.state = 379
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2, 21, 47, 48, 49, 50, 51]:
                self.enterOuterAlt(localctx, 1)
                self.state = 373
                self.postfixExpression(0)
                pass
            elif token in [15, 28, 29]:
                self.enterOuterAlt(localctx, 2)
                self.state = 374
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 805339136) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 375
                self.unaryExpression()
                pass
            elif token in [11, 12]:
                self.enterOuterAlt(localctx, 3)
                self.state = 376
                self.referenceOp()
                self.state = 377
                self.unaryExpression()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PostfixExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primaryExpression(self):
            return self.getTypedRuleContext(CPPParser.PrimaryExpressionContext,0)


        def postfixExpression(self):
            return self.getTypedRuleContext(CPPParser.PostfixExpressionContext,0)


        def INCREMENT(self):
            return self.getToken(CPPParser.INCREMENT, 0)

        def DECREMENT(self):
            return self.getToken(CPPParser.DECREMENT, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_postfixExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPostfixExpression" ):
                listener.enterPostfixExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPostfixExpression" ):
                listener.exitPostfixExpression(self)



    def postfixExpression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CPPParser.PostfixExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 60
        self.enterRecursionRule(localctx, 60, self.RULE_postfixExpression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 382
            self.primaryExpression()
            self._ctx.stop = self._input.LT(-1)
            self.state = 388
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,38,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CPPParser.PostfixExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_postfixExpression)
                    self.state = 384
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 385
                    _la = self._input.LA(1)
                    if not(_la==28 or _la==29):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume() 
                self.state = 390
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,38,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class PrimaryExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable(self):
            return self.getTypedRuleContext(CPPParser.VariableContext,0)


        def number(self):
            return self.getTypedRuleContext(CPPParser.NumberContext,0)


        def functionCall(self):
            return self.getTypedRuleContext(CPPParser.FunctionCallContext,0)


        def CHAR_LITERAL(self):
            return self.getToken(CPPParser.CHAR_LITERAL, 0)

        def STRING_LITERAL(self):
            return self.getToken(CPPParser.STRING_LITERAL, 0)

        def BOOL_LITERAL(self):
            return self.getToken(CPPParser.BOOL_LITERAL, 0)

        def LPAREN(self):
            return self.getToken(CPPParser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(CPPParser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(CPPParser.RPAREN, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_primaryExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimaryExpression" ):
                listener.enterPrimaryExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimaryExpression" ):
                listener.exitPrimaryExpression(self)




    def primaryExpression(self):

        localctx = CPPParser.PrimaryExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_primaryExpression)
        try:
            self.state = 401
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,39,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 391
                self.variable()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 392
                self.number()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 393
                self.functionCall()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 394
                self.match(CPPParser.CHAR_LITERAL)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 395
                self.match(CPPParser.STRING_LITERAL)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 396
                self.match(CPPParser.BOOL_LITERAL)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 397
                self.match(CPPParser.LPAREN)
                self.state = 398
                self.expression(0)
                self.state = 399
                self.match(CPPParser.RPAREN)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable_(self):
            return self.getTypedRuleContext(CPPParser.Variable_Context,0)


        def ID(self):
            return self.getToken(CPPParser.ID, 0)

        def SCOPE(self):
            return self.getToken(CPPParser.SCOPE, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable" ):
                listener.enterVariable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable" ):
                listener.exitVariable(self)




    def variable(self):

        localctx = CPPParser.VariableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_variable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 405
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,40,self._ctx)
            if la_ == 1:
                self.state = 403
                self.match(CPPParser.ID)
                self.state = 404
                self.match(CPPParser.SCOPE)


            self.state = 407
            self.variable_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Variable_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CPPParser.ID, 0)

        def LBRACK(self):
            return self.getToken(CPPParser.LBRACK, 0)

        def expression(self):
            return self.getTypedRuleContext(CPPParser.ExpressionContext,0)


        def RBRACK(self):
            return self.getToken(CPPParser.RBRACK, 0)

        def DOT(self):
            return self.getToken(CPPParser.DOT, 0)

        def variable_(self):
            return self.getTypedRuleContext(CPPParser.Variable_Context,0)


        def getRuleIndex(self):
            return CPPParser.RULE_variable_

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable_" ):
                listener.enterVariable_(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable_" ):
                listener.exitVariable_(self)




    def variable_(self):

        localctx = CPPParser.Variable_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_variable_)
        try:
            self.state = 419
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,42,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 409
                self.match(CPPParser.ID)
                self.state = 414
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,41,self._ctx)
                if la_ == 1:
                    self.state = 410
                    self.match(CPPParser.LBRACK)
                    self.state = 411
                    self.expression(0)
                    self.state = 412
                    self.match(CPPParser.RBRACK)


                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 416
                self.match(CPPParser.ID)
                self.state = 417
                self.match(CPPParser.DOT)
                self.state = 418
                self.variable_()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function_(self):
            return self.getTypedRuleContext(CPPParser.Function_Context,0)


        def ID(self):
            return self.getToken(CPPParser.ID, 0)

        def SCOPE(self):
            return self.getToken(CPPParser.SCOPE, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction" ):
                listener.enterFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction" ):
                listener.exitFunction(self)




    def function(self):

        localctx = CPPParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_function)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 423
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,43,self._ctx)
            if la_ == 1:
                self.state = 421
                self.match(CPPParser.ID)
                self.state = 422
                self.match(CPPParser.SCOPE)


            self.state = 425
            self.function_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CPPParser.ID, 0)

        def DOT(self):
            return self.getToken(CPPParser.DOT, 0)

        def function_(self):
            return self.getTypedRuleContext(CPPParser.Function_Context,0)


        def getRuleIndex(self):
            return CPPParser.RULE_function_

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_" ):
                listener.enterFunction_(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_" ):
                listener.exitFunction_(self)




    def function_(self):

        localctx = CPPParser.Function_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_function_)
        try:
            self.state = 431
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,44,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 427
                self.match(CPPParser.ID)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 428
                self.match(CPPParser.ID)
                self.state = 429
                self.match(CPPParser.DOT)
                self.state = 430
                self.function_()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function(self):
            return self.getTypedRuleContext(CPPParser.FunctionContext,0)


        def LPAREN(self):
            return self.getToken(CPPParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(CPPParser.RPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(CPPParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CPPParser.RULE_functionCall

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionCall" ):
                listener.enterFunctionCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionCall" ):
                listener.exitFunctionCall(self)




    def functionCall(self):

        localctx = CPPParser.FunctionCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_functionCall)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 433
            self.function()
            self.state = 434
            self.match(CPPParser.LPAREN)
            self.state = 436
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 4362862946457606) != 0):
                self.state = 435
                self.expression(0)


            self.state = 438
            self.match(CPPParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self):
            return self.getToken(CPPParser.NUMBER, 0)

        def MINUS(self):
            return self.getToken(CPPParser.MINUS, 0)

        def PLUS(self):
            return self.getToken(CPPParser.PLUS, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = CPPParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 441
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1 or _la==2:
                self.state = 440
                _la = self._input.LA(1)
                if not(_la==1 or _la==2):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 443
            self.match(CPPParser.NUMBER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclaratorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CPPParser.ID, 0)

        def LBRACK(self):
            return self.getToken(CPPParser.LBRACK, 0)

        def NUMBER(self):
            return self.getToken(CPPParser.NUMBER, 0)

        def RBRACK(self):
            return self.getToken(CPPParser.RBRACK, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_declarator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclarator" ):
                listener.enterDeclarator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclarator" ):
                listener.exitDeclarator(self)




    def declarator(self):

        localctx = CPPParser.DeclaratorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_declarator)
        try:
            self.state = 450
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 445
                self.match(CPPParser.ID)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 446
                self.match(CPPParser.ID)
                self.state = 447
                self.match(CPPParser.LBRACK)
                self.state = 448
                self.match(CPPParser.NUMBER)
                self.state = 449
                self.match(CPPParser.RBRACK)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShiftOperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GT(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.GT)
            else:
                return self.getToken(CPPParser.GT, i)

        def LT(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.LT)
            else:
                return self.getToken(CPPParser.LT, i)

        def getRuleIndex(self):
            return CPPParser.RULE_shiftOperator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShiftOperator" ):
                listener.enterShiftOperator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShiftOperator" ):
                listener.exitShiftOperator(self)




    def shiftOperator(self):

        localctx = CPPParser.ShiftOperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_shiftOperator)
        try:
            self.state = 456
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [6]:
                self.enterOuterAlt(localctx, 1)
                self.state = 452
                self.match(CPPParser.GT)
                self.state = 453
                self.match(CPPParser.GT)
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 454
                self.match(CPPParser.LT)
                self.state = 455
                self.match(CPPParser.LT)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncludeIDContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(CPPParser.ID)
            else:
                return self.getToken(CPPParser.ID, i)

        def DOT(self):
            return self.getToken(CPPParser.DOT, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_includeID

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIncludeID" ):
                listener.enterIncludeID(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIncludeID" ):
                listener.exitIncludeID(self)




    def includeID(self):

        localctx = CPPParser.IncludeIDContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_includeID)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 458
            self.match(CPPParser.ID)
            self.state = 461
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==18:
                self.state = 459
                self.match(CPPParser.DOT)
                self.state = 460
                self.match(CPPParser.ID)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReferenceOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ASTERISK(self):
            return self.getToken(CPPParser.ASTERISK, 0)

        def AMPERSAND(self):
            return self.getToken(CPPParser.AMPERSAND, 0)

        def getRuleIndex(self):
            return CPPParser.RULE_referenceOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReferenceOp" ):
                listener.enterReferenceOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReferenceOp" ):
                listener.exitReferenceOp(self)




    def referenceOp(self):

        localctx = CPPParser.ReferenceOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_referenceOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 463
            _la = self._input.LA(1)
            if not(_la==11 or _la==12):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[20] = self.expression_sempred
        self._predicates[22] = self.logicalOrExpression_sempred
        self._predicates[23] = self.logicalAndExpression_sempred
        self._predicates[24] = self.equalityExpression_sempred
        self._predicates[27] = self.additiveExpression_sempred
        self._predicates[28] = self.multiplicativeExpression_sempred
        self._predicates[30] = self.postfixExpression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 1)
         

    def logicalOrExpression_sempred(self, localctx:LogicalOrExpressionContext, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 1)
         

    def logicalAndExpression_sempred(self, localctx:LogicalAndExpressionContext, predIndex:int):
            if predIndex == 2:
                return self.precpred(self._ctx, 1)
         

    def equalityExpression_sempred(self, localctx:EqualityExpressionContext, predIndex:int):
            if predIndex == 3:
                return self.precpred(self._ctx, 1)
         

    def additiveExpression_sempred(self, localctx:AdditiveExpressionContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 1)
         

    def multiplicativeExpression_sempred(self, localctx:MultiplicativeExpressionContext, predIndex:int):
            if predIndex == 5:
                return self.precpred(self._ctx, 1)
         

    def postfixExpression_sempred(self, localctx:PostfixExpressionContext, predIndex:int):
            if predIndex == 6:
                return self.precpred(self._ctx, 1)
         




